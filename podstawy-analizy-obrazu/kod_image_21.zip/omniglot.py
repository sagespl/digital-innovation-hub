import os
import random
import torch
from torch import nn
from torch.utils.data import Dataset
from PIL import Image


class OmniglotDataset(Dataset):
    def __init__(self, root_dir, set_size, transform=None):
        self.root_dir = root_dir
        self.categories = [[folder, [subfolder for subfolder in os.listdir(root_dir + folder) 
                                     if not subfolder.startswith(".")]]
                           for folder in os.listdir(root_dir) 
                           if not folder.startswith(".")]
        self.transform = transform
        self.set_size = set_size
    def __len__(self):
        return self.set_size
    def __getitem__(self, idx):
        img1 = None
        img2 = None
        label = None
        if idx % 2 == 0:
            category = random.choice(self.categories)
            character = random.choice(category[1])
            img_dir = f"{self.root_dir}{category[0]}/{character}"
            img1_name = random.choice(os.listdir(img_dir))
            img2_name = random.choice(os.listdir(img_dir))
            img1 = Image.open(f"{img_dir}/{img1_name}")
            img2 = Image.open(f"{img_dir}/{img2_name}")
            label = 1.0
        else:
            category1, category2 = random.choice(self.categories), random.choice(self.categories)
            character1, character2 = random.choice(category1[1]), random.choice(category2[1])
            img_dir1 = f"{self.root_dir}{category1[0]}/{character1}"
            img_dir2 = f"{self.root_dir}{category2[0]}/{character2}"
            img1_name = random.choice(os.listdir(img_dir1))
            img2_name = random.choice(os.listdir(img_dir2))
            while img1_name == img2_name:
                img2_name = random.choice(os.listdir(img_dir2))
            label = 0.0
            img1 = Image.open(f"{img_dir1}/{img1_name}")
            img2 = Image.open(f"{img_dir2}/{img2_name}")
        
        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)
        return img1, img2, torch.tensor([label], dtype=torch.float32)


class NWayOmniglotDataset(Dataset):
    def __init__(self, root_dir, set_size, num_way, transform=None):
        self.root_dir = root_dir
        self.categories = [[folder, [subfolder for subfolder in os.listdir(root_dir + folder) 
                                     if not subfolder.startswith(".")]]
                           for folder in os.listdir(root_dir) 
                           if not folder.startswith(".")]
        self.set_size = set_size
        self.num_way = num_way
        self.transform = transform
    def __len__(self):
        return self.set_size
    def __getitem__(self, idx):
        category = random.choice(self.categories)
        character = random.choice(category[1])
        img_dir = f"{self.root_dir}{category[0]}/{character}"
        img_name = random.choice(os.listdir(img_dir))
        main_img = Image.open(f"{img_dir}/{img_name}")

        if self.transform:
            main_img = self.transform(main_img)
        
        test_set = []
        label = random.randint(0, self.num_way - 1)
        for i in range(self.num_way):
            test_img_dir = img_dir
            test_img_name = ""
            if i == label:
                test_img_name = random.choice(os.listdir(img_dir))
            else:
                test_category = random.choice(self.categories)
                test_character = random.choice(test_category[1])
                test_img_dir = f"{self.root_dir}{test_category[0]}/{test_character}"
                while test_img_dir == img_dir:
                    test_character = random.choice(test_category[1])
                    test_img_dir = f"{self.root_dir}{test_category[0]}/{test_character}"
                test_img_name = random.choice(os.listdir(test_img_dir))
            test_img = Image.open(f"{test_img_dir}/{test_img_name}")
            if self.transform:
                test_img = self.transform(test_img)
            test_set.append(test_img)

        return main_img, test_set, torch.tensor([label], dtype=torch.int16)


class SiameseNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv11 = nn.Conv2d(1, 64, 3) 
        self.conv12 = nn.Conv2d(64, 64, 3)  
        self.conv21 = nn.Conv2d(64, 128, 3)
        self.conv22 = nn.Conv2d(128, 128, 3)
        self.conv31 = nn.Conv2d(128, 256, 3) 
        self.conv32 = nn.Conv2d(256, 256, 3)  
        self.conv33 = nn.Conv2d(256, 256, 3)
        self.pool = nn.MaxPool2d(2, 2)
        self.relu = nn.ReLU()
        self.fc1 = nn.Linear(256 * 8 * 8, 4096)
        self.fc2 = nn.Linear(4096, 4096)
        self.fcOut = nn.Linear(4096, 1)
        self.sigmoid = nn.Sigmoid()
    
    def convs(self, x):
        x = self.relu(self.conv11(x))
        x = self.relu(self.conv12(x))
        x = self.pool(x)
        x = self.relu(self.conv21(x))
        x = self.relu(self.conv22(x))
        x = self.pool(x)
        x = self.relu(self.conv31(x))
        x = self.relu(self.conv32(x))
        x = self.relu(self.conv33(x))
        x = self.pool(x)
        return x

    def forward(self, x1, x2):
        x1 = self.convs(x1)
        x1 = x1.reshape(-1, 256 * 8 * 8)
        x1 = self.fc1(x1)
        x1 = self.sigmoid(self.fc2(x1))
        x2 = self.convs(x2)
        x2 = x2.reshape(-1, 256 * 8 * 8)
        x2 = self.fc1(x2)
        x2 = self.sigmoid(self.fc2(x2))
        x = torch.abs(x1 - x2)
        x = self.fcOut(x)
        return x
